"""File management utilities"""
import os
from logger_config import logger

def load_smtp_credentials():
    smtp_configs = []
    with open("smtp.txt", "r") as f:
        for line in f:
            parts = line.strip().split("|")
            if len(parts) == 2:
                hostname, port = parts
                smtp_configs.append({
                    "hostname": hostname,
                    "port": int(port),
                    "auth": False
                })
            elif len(parts) == 4:
                hostname, port, username, password = parts
                smtp_configs.append({
                    "hostname": hostname,
                    "port": int(port),
                    "username": username,
                    "password": password,
                    "auth": True
                })
    return smtp_configs

def load_allowed_user_ids():
    """Load allowed user IDs from user.txt file"""
    if not os.path.exists("user.txt"):
        with open("user.txt", "w") as f:
            pass  # Create empty file if it doesn't exist
        return set()

    try:  
        with open("user.txt", "r") as file:  
            user_ids = {int(line.strip()) for line in file if line.strip().isdigit()}  
        return user_ids  
    except Exception as e:
        logger.error(f"Error loading allowed user IDs: {str(e)}")
        return set()

def add_user_to_allowed_list(user_id):
    """Add a user ID to the allowed users list"""
    try:
        existing_users = load_allowed_user_ids()
        if user_id in existing_users:
            logger.info(f"User {user_id} already in allowed list")
            return True  # User already in the list, but return True as they're authorized
        
        with open("user.txt", "a") as file:
            file.write(f"{user_id}\n")
        
        logger.info(f"Successfully added user {user_id} to allowed list")
        return True
    except Exception as e:
        logger.error(f"Error adding user {user_id} to allowed list: {str(e)}")
        return False
