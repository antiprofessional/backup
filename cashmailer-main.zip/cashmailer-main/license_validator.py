"""License key validation utilities"""
import requests
from config import LICENSE_KEY_URL
from logger_config import logger

def validate_license_key(key):
    """Validate license key against the remote list"""
    try:
        logger.info(f"Validating license key: {key}")
        
        # Make request with proper headers and timeout
        headers = {
            'User-Agent': 'AceMailerBot/1.0',
            'Accept': 'text/plain'
        }
        
        response = requests.get(LICENSE_KEY_URL, headers=headers, timeout=15)
        logger.info(f"License validation response: HTTP {response.status_code}")
        
        if response.status_code == 200:
            # Get all license keys from the response
            license_keys = [line.strip() for line in response.text.splitlines() if line.strip()]
            logger.info(f"Found {len(license_keys)} license keys in remote list")
            
            # Check if the provided key is in the list
            is_valid = key.strip() in license_keys
            logger.info(f"License key validation result: {is_valid}")
            
            return is_valid
        else:
            logger.error(f"Failed to fetch license keys: HTTP {response.status_code}")
            return False
            
    except requests.exceptions.Timeout:
        logger.error("Timeout while validating license key")
        return False
    except requests.exceptions.ConnectionError:
        logger.error("Connection error while validating license key")
        return False
    except Exception as e:
        logger.error(f"Error validating license key: {str(e)}")
        return False

def get_license_keys_from_server():
    """Fetch all license keys from the server for admin purposes"""
    try:
        headers = {
            'User-Agent': 'AceMailerBot/1.0',
            'Accept': 'text/plain'
        }
        response = requests.get(LICENSE_KEY_URL, headers=headers, timeout=15)
        if response.status_code == 200:
            license_keys = [line.strip() for line in response.text.splitlines() if line.strip()]
            return license_keys, None
        else:
            return None, f"HTTP {response.status_code}"
    except Exception as e:
        return None, str(e)
