"""Admin panel handlers"""
import os
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from config import ADMIN_ID
from file_manager import load_allowed_user_ids, load_smtp_credentials
from license_validator import get_license_keys_from_server
from template_manager import get_templates, add_template, delete_template

async def admin_panel(update, context):
    """Display admin panel options"""
    user_id = update.effective_user.id

    if user_id != ADMIN_ID:  
        await update.message.reply_text("You are not authorized to access the admin panel.")  
        return  
          
    keyboard = [  
        [InlineKeyboardButton("👥 User Management", callback_data="admin_user_management")],
        [InlineKeyboardButton("📝 Template Management", callback_data="admin_templates")],
        [InlineKeyboardButton("🔧 System Settings", callback_data="admin_system_settings")],
        [InlineKeyboardButton("📊 Statistics", callback_data="admin_stats")]
    ]  
    await update.message.reply_text(
        "🔐 *ADMIN PANEL*\n\n"
        "Welcome to the Admin Panel. Select an option below:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

async def handle_admin_action(update, context):
    """Handle admin panel button clicks"""
    user_id = update.effective_user.id

    if user_id != ADMIN_ID:  
        return  
          
    query = update.callback_query  
    action = query.data  
      
    await query.answer()  
    context.user_data["admin_action"] = action  
    
    # User Management Section
    if action == "admin_user_management":
        keyboard = [
            [InlineKeyboardButton("➕ Add User", callback_data="admin_add")],  
            [InlineKeyboardButton("➖ Remove User", callback_data="admin_remove")],  
            [InlineKeyboardButton("📃 List Users", callback_data="admin_list")],
            [InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="admin_back")]
        ]
        await query.edit_message_text(
            "👥 *USER MANAGEMENT*\n\n"
            "Manage authorized users:",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    
    # Template Management Section
    elif action == "admin_templates":
        # Show template management options
        keyboard = [
            [InlineKeyboardButton("📋 List Templates", callback_data="admin_list_templates")],
            [InlineKeyboardButton("➕ Add Template", callback_data="admin_add_template")],
            [InlineKeyboardButton("➖ Delete Template", callback_data="admin_delete_template")],
            [InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="admin_back")]
        ]
        await query.edit_message_text(
            "📝 *TEMPLATE MANAGEMENT*\n\n"
            "Manage email templates:",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    
    # System Settings Section
    elif action == "admin_system_settings":
        keyboard = [
            [InlineKeyboardButton("📧 Check SMTP", callback_data="admin_smtp")],
            [InlineKeyboardButton("🔑 Check License Keys", callback_data="admin_check_licenses")],
            [InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="admin_back")]
        ]
        await query.edit_message_text(
            "🔧 *SYSTEM SETTINGS*\n\n"
            "Configure system settings:",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    
    # Statistics Section
    elif action == "admin_stats":
        # Get some basic stats
        user_count = len(load_allowed_user_ids())
        template_count = len(get_templates())
        
        keyboard = [[InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="admin_back")]]
        await query.edit_message_text(
            "📊 *SYSTEM STATISTICS*\n\n"
            f"👥 Authorized Users: {user_count}\n"
            f"📝 Available Templates: {template_count}\n\n"
            "More detailed statistics coming soon.",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    
    # User Management Actions
    elif action == "admin_add":  
        await query.edit_message_text(
            "➕ *ADD USER*\n\n"
            "Send the User ID to add:",
            parse_mode=ParseMode.MARKDOWN
        )
    
    elif action == "admin_remove":  
        await query.edit_message_text(
            "➖ *REMOVE USER*\n\n"
            "Send the User ID to remove:",
            parse_mode=ParseMode.MARKDOWN
        )
    
    elif action == "admin_list":  
        user_ids = load_allowed_user_ids()  
        if not user_ids:  
            await query.edit_message_text(
                "No authorized users found.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_user_management")]])
            )
        else:  
            msg = "\n".join(str(uid) for uid in sorted(user_ids))  
            await query.edit_message_text(
                f"<b>Authorized Users ({len(user_ids)}):</b>\n<code>{msg}</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_user_management")]])
            )
    
    # System Settings Actions
    elif action == "admin_smtp":  
        smtp_configs = load_smtp_credentials()  
        if not smtp_configs:  
            await query.edit_message_text(
                "No SMTP configurations found in smtp.txt!",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_system_settings")]])
            )
        else:  
            msg = "\n".join([f"{config['hostname']}:{config['port']} ({config['username']})" for config in smtp_configs])  
            await query.edit_message_text(
                f"<b>SMTP Configurations ({len(smtp_configs)}):</b>\n<code>{msg}</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_system_settings")]])
            )
    
    elif action == "admin_check_licenses":
        await query.edit_message_text("🔄 Fetching license keys from server...")
        license_keys, error = get_license_keys_from_server()
        
        if error:
            await query.edit_message_text(
                f"❌ Error checking license keys: {error}",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_system_settings")]])
            )
        elif not license_keys:
            await query.edit_message_text(
                "❌ No license keys found on the server.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_system_settings")]])
            )
        else:
            # Show first 20 keys to avoid message size limits
            keys_to_show = license_keys[:20]
            msg = "\n".join(keys_to_show)
            extra_count = len(license_keys) - 20
            
            response_text = f"<b>🔑 License Keys ({len(license_keys)} total):</b>\n<code>{msg}</code>"
            if extra_count > 0:
                response_text += f"\n\n<i>... and {extra_count} more keys</i>"
            
            await query.edit_message_text(
                response_text,
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_system_settings")]])
            )
    
    # Template Management Actions
    elif action == "admin_list_templates":
        templates = get_templates()
        if not templates:
            await query.edit_message_text(
                "No templates found. Use 'Add Template' to create new templates.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_templates")]])
            )
        else:
            msg = "\n\n".join([
                f"<b>{i+1}. {template['name']}</b>\n"
                f"ID: <code>{template['id']}</code>\n"
                f"Subject: <code>{template['subject']}</code>\n"
                f"Description: {template['description']}"
                for i, template in enumerate(templates)
            ])
            await query.edit_message_text(
                f"<b>📝 Available Templates ({len(templates)}):</b>\n\n{msg}",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_templates")]])
            )
    
    elif action == "admin_add_template":
        await query.edit_message_text(
            "➕ *ADD TEMPLATE*\n\n"
            "To add a new template, please provide the following information in this format:\n\n"
            "`Template Name | Description | Subject | HTML Content`\n\n"
            "For example:\n"
            "`Welcome Email | A welcome message for new users | Welcome to Our Service! | <html>...</html>`\n\n"
            "You can also upload an HTML file and then send the first three parts in the format:\n"
            "`Template Name | Description | Subject`",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_templates")]])
        )
        context.user_data["admin_template_action"] = "add"
    
    elif action == "admin_delete_template":
        templates = get_templates()
        if not templates:
            await query.edit_message_text(
                "No templates found to delete.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_templates")]])
            )
        else:
            keyboard = []
            for template in templates:
                keyboard.append([InlineKeyboardButton(
                    f"{template['name']} ({template['id']})", 
                    callback_data=f"delete_template_{template['id']}"
                )])
            keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="admin_templates")])
            
            await query.edit_message_text(
                "Select a template to delete:",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
    
    elif action.startswith("delete_template_"):
        template_id = action.replace("delete_template_", "")
        
        # Show confirmation dialog
        keyboard = [
            [
                InlineKeyboardButton("✅ Yes, Delete", callback_data=f"confirm_delete_{template_id}"),
                InlineKeyboardButton("❌ No, Cancel", callback_data="admin_delete_template")
            ]
        ]
        
        await query.edit_message_text(
            f"⚠️ *CONFIRM DELETION*\n\n"
            f"Are you sure you want to delete template '{template_id}'?\n\n"
            f"This action cannot be undone.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    elif action.startswith("confirm_delete_"):
        template_id = action.replace("confirm_delete_", "")
        success = delete_template(template_id)
        
        if success:
            await query.edit_message_text(
                f"✅ Template '{template_id}' deleted successfully.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_templates")]])
            )
        else:
            await query.edit_message_text(
                f"❌ Failed to delete template '{template_id}'.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_templates")]])
            )
    
    # Navigation
    elif action == "admin_back":
        await admin_panel(update, context)

async def handle_admin_input(update, context):
    """Process admin input for user management"""
    user_id = update.effective_user.id

    if user_id != ADMIN_ID:  
        return  
    
    # Check if we're in template add mode
    if context.user_data.get("admin_template_action") == "add":
        # Check if an HTML file was uploaded
        if update.message.document and update.message.document.mime_type == "text/html":
            file = await update.message.document.get_file()
            file_path = f"temp_template_{user_id}.html"
            await file.download_to_drive(file_path)
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    html_content = f.read()
                
                context.user_data["template_html"] = html_content
                
                # Create back button
                keyboard = [[InlineKeyboardButton("🔙 Cancel", callback_data="admin_templates")]]
                
                await update.message.reply_text(
                    "HTML file received. Now please send the template details in this format:\n\n"
                    "<code>Template Name | Description | Subject</code>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            except Exception as e:
                await update.message.reply_text(f"Error reading HTML file: {str(e)}")
            finally:
                # Clean up temp file
                if os.path.exists(file_path):
                    os.remove(file_path)
            
            return
        
        # Process template text input
        template_text = update.message.text.strip()
        
        # Check if we already have HTML content from a file
        if "template_html" in context.user_data:
            # Format should be: Name | Description | Subject
            parts = template_text.split('|', 2)
            if len(parts) != 3:
                await update.message.reply_text(
                    "Invalid format. Please use: Template Name | Description | Subject"
                )
                return
            
            name, description, subject = [p.strip() for p in parts]
            html_content = context.user_data["template_html"]
            
            # Add the template
            success = add_template(name, description, subject, html_content)
            
            if success:
                # Create back button
                keyboard = [[InlineKeyboardButton("🔙 Back to Templates", callback_data="admin_templates")]]
                
                await update.message.reply_text(
                    f"✅ Template '{name}' added successfully.",
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            else:
                await update.message.reply_text(f"❌ Failed to add template '{name}'.")
            
            # Clean up
            context.user_data.pop("admin_template_action", None)
            context.user_data.pop("template_html", None)
            return
        
        # Format should be: Name | Description | Subject | HTML Content
        parts = template_text.split('|', 3)
        if len(parts) != 4:
            await update.message.reply_text(
                "Invalid format. Please use: Template Name | Description | Subject | HTML Content\n\n"
                "Or upload an HTML file first."
            )
            return
        
        name, description, subject, html_content = [p.strip() for p in parts]
        
        # Add the template
        success = add_template(name, description, subject, html_content)
        
        if success:
            # Create back button
            keyboard = [[InlineKeyboardButton("🔙 Back to Templates", callback_data="admin_templates")]]
            
            await update.message.reply_text(
                f"✅ Template '{name}' added successfully.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await update.message.reply_text(f"❌ Failed to add template '{name}'.")
        
        # Clean up
        context.user_data.pop("admin_template_action", None)
        return
          
    action = context.user_data.get("admin_action")  
    if not action:  
        return  
          
    user_id_text = update.message.text.strip()  
      
    if not user_id_text.isdigit():  
        await update.message.reply_text("Invalid User ID. Please enter a numeric ID.")  
        return  
          
    target_user_id = int(user_id_text)  
    existing = load_allowed_user_ids()  
      
    if action == "admin_add":  
        if target_user_id in existing:  
            await update.message.reply_text(
                f"User {target_user_id} is already authorized.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_user_management")]])
            )
        else:  
            try:  
                with open("user.txt", "a") as f:  
                    f.write(f"{target_user_id}\n")  
                await update.message.reply_text(
                    f"✅ User {target_user_id} added to the whitelist.",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_user_management")]])
                )
            except Exception as e:  
                await update.message.reply_text(f"❌ Error adding user: {str(e)}")  
    elif action == "admin_remove":  
        if target_user_id not in existing:  
            await update.message.reply_text(
                f"User {target_user_id} not found in the whitelist.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_user_management")]])
            )
        else:  
            try:  
                existing.discard(target_user_id)  
                with open("user.txt", "w") as f:  
                    for uid in sorted(existing):  
                        f.write(f"{uid}\n")  
                await update.message.reply_text(
                    f"✅ User {target_user_id} removed from the whitelist.",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_user_management")]])
                )
            except Exception as e:  
                await update.message.reply_text(f"❌ Error removing user: {str(e)}")  
      
    # Clear the admin action after processing  
    context.user_data.pop("admin_action", None)
